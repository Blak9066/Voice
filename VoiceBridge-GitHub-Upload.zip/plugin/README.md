# VoiceBridge

Proximity voice chat for Minecraft (Paper 1.21.1, Java server) where players — including Bedrock players
via Geyser/Floodgate — talk through a **phone app**.

## Build
    mvn clean package        # -> target/VoiceBridge-1.0.0.jar  (Java 17+)
Put the jar in `plugins/`, start once, edit `plugins/VoiceBridge/config.yml` (public-host + port), restart.
**Open the TCP port (default 25590)** in firewall / hosting panel.

## Player flow
1. Join the server, open the app
2. `/vc code`  -> chat shows a one-time code
3. App: enter player name + code -> connected
4. `/vc` -> menu (mic on/off, hear on/off, noise suppression, mic device, speaker)

Commands: `/vc`, `/vc code`, `/vc mute`, `/vc deafen`, `/vc noise`, `/vc status`, `/vc disconnect`, `/vc reload`

## Protocol (for the app)
Connect: `ws://host:port` (or `wss://` with TLS). Login within 10 s.

### Client -> server (JSON text)
    {"type":"login","name":"Steve","code":"123456"}
    {"type":"state","muted":true,"deafened":false,"noise":true}          // any subset, when user toggles in-app
    {"type":"devices","inputs":[{"id":"a","name":"Phone mic"}],"outputs":[{"id":"b","name":"Speaker"}],
     "selectedInput":"a","selectedOutput":"b"}                           // send after login and whenever devices change

### Server -> client (JSON text)
    {"type":"welcome","id":7,"name":"Steve","maxDistance":30,"audio":{"codec":"opus","sampleRate":48000,"frameMs":20,"channels":1},"state":{...}}
    {"type":"error","code":"invalid_login","message":"..."}
    {"type":"state","muted":false,"deafened":false,"noise":true}         // changed from the in-game menu -> apply it
    {"type":"setDevice","kind":"input"|"output","id":"a"}                // chosen in the in-game menu -> switch device
    {"type":"nearby","players":[{"id":3,"name":"Alex","dist":12.4,"muted":false}]}   // twice a second

### Audio (binary, Opus 48 kHz mono, 20 ms frames)
    client -> server : [0x01][seq u16 BE][opus...]
    server -> client : [0x02][srcId i32 BE][gain u8 0..255][pan i8 -100..100][seq u16 BE][opus...]
Server only forwards frames to players within `max-distance` (30 blocks) and in the same world.
Client: decode per srcId (own jitter buffer), play at `gain/255`, pan `-100` = left ear, `+100` = right ear.
Noise suppression is done by the app (the flag is just the toggle).
