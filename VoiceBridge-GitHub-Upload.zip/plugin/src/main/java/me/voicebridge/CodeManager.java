package me.voicebridge;

import org.bukkit.entity.Player;

import java.security.SecureRandom;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** One-time login codes: /vc code -> type name + code in the app. */
public final class CodeManager {
    public record PendingCode(UUID playerId, String playerName, long expiresAt) {}

    private final VoiceBridgePlugin plugin;
    private final Map<String, PendingCode> codes = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();

    public CodeManager(VoiceBridgePlugin plugin) {
        this.plugin = plugin;
    }

    public String create(Player player) {
        long now = System.currentTimeMillis();
        codes.values().removeIf(c -> c.expiresAt() < now || c.playerId().equals(player.getUniqueId()));

        Settings s = plugin.settings();
        PendingCode pending = new PendingCode(player.getUniqueId(), player.getName(),
                now + s.codeExpireSeconds * 1000L);
        String code;
        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.codeLength; i++) sb.append(random.nextInt(10));
            code = sb.toString();
        } while (codes.putIfAbsent(code, pending) != null);
        return code;
    }

    /** Returns the pending entry if the code exists and has not expired (does not consume it). */
    public PendingCode find(String code) {
        if (code == null) return null;
        PendingCode p = codes.get(code.trim());
        if (p == null) return null;
        if (p.expiresAt() < System.currentTimeMillis()) {
            codes.remove(code.trim(), p);
            return null;
        }
        return p;
    }

    public void consume(String code, PendingCode p) {
        codes.remove(code.trim(), p);
    }

    public void removeFor(UUID playerId) {
        codes.values().removeIf(c -> c.playerId().equals(playerId));
    }
}
