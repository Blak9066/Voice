package me.voicebridge;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class VoiceBridgePlugin extends JavaPlugin implements Listener {
    private volatile Settings settings;
    private Messages messages;
    private PositionTracker positions;
    private CodeManager codes;
    private VoiceServer voice;
    private MenuService menus;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(getConfig());
        messages = new Messages(this);
        positions = new PositionTracker(this);
        codes = new CodeManager(this);

        try {
            voice = new VoiceServer(this);
            voice.launch();
        } catch (Exception ex) {
            getLogger().severe("Could not start the voice server: " + ex.getMessage());
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        menus = new MenuService(this);
        Bukkit.getPluginManager().registerEvents(menus, this);
        Bukkit.getPluginManager().registerEvents(this, this);

        VcCommand cmd = new VcCommand(this);
        getCommand("vc").setExecutor(cmd);
        getCommand("vc").setTabCompleter(cmd);
    }

    @Override
    public void onDisable() {
        if (voice != null) voice.shutdown();
    }

    public void reload() {
        reloadConfig();
        settings = new Settings(getConfig());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        voice.disconnect(e.getPlayer().getUniqueId());
        codes.removeFor(e.getPlayer().getUniqueId());
        positions.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!settings.joinHint) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && voice.session(p.getUniqueId()) == null) messages.send(p, "join-hint");
        }, 40L);
    }

    public Settings settings() { return settings; }
    public Messages messages() { return messages; }
    public PositionTracker positions() { return positions; }
    public CodeManager codes() { return codes; }
    public VoiceServer voice() { return voice; }
    public MenuService menus() { return menus; }
}
