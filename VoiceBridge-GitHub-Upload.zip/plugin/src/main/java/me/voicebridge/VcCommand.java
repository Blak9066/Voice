package me.voicebridge;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class VcCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBS = List.of("menu", "code", "mute", "deafen", "noise", "status", "disconnect", "reload");
    private final VoiceBridgePlugin plugin;

    public VcCommand(VoiceBridgePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Messages m = plugin.messages();
        String sub = args.length == 0 ? "menu" : args[0].toLowerCase(Locale.ROOT);

        if (sub.equals("reload")) {
            if (!sender.hasPermission("voicebridge.admin")) {
                m.send(sender, "no-permission");
            } else {
                plugin.reload();
                m.send(sender, "reloaded");
            }
            return true;
        }
        if (!(sender instanceof Player p)) {
            m.send(sender, "only-players");
            return true;
        }

        VoiceServer voice = plugin.voice();
        VoiceSession s = voice.session(p.getUniqueId());

        switch (sub) {
            case "menu" -> plugin.menus().open(p);
            case "code" -> {
                Settings st = plugin.settings();
                String code = plugin.codes().create(p);
                m.send(p, "code-created", "code", code, "minutes", String.valueOf(Math.max(1, st.codeExpireSeconds / 60)));
                m.send(p, "code-help",
                        "name", VoiceServer.stripPrefix(p.getName(), st.floodgatePrefix),
                        "address", st.publicHost + ":" + st.port);
            }
            case "mute" -> {
                if (s == null) { m.send(p, "not-connected"); break; }
                voice.applyChanges(s, !s.muted, s.deafened, s.noise, null, null);
                m.send(p, s.muted ? "mic-off" : "mic-on");
            }
            case "deafen" -> {
                if (s == null) { m.send(p, "not-connected"); break; }
                voice.applyChanges(s, s.muted, !s.deafened, s.noise, null, null);
                m.send(p, s.deafened ? "hear-off" : "hear-on");
            }
            case "noise" -> {
                if (s == null) { m.send(p, "not-connected"); break; }
                voice.applyChanges(s, s.muted, s.deafened, !s.noise, null, null);
                m.send(p, s.noise ? "noise-on" : "noise-off");
            }
            case "status" -> {
                if (s == null) { m.send(p, "not-connected"); break; }
                m.send(p, "status",
                        "mic", m.raw(s.muted ? "state-off" : "state-on"),
                        "hear", m.raw(s.deafened ? "state-off" : "state-on"),
                        "noise", m.raw(s.noise ? "state-on" : "state-off"));
            }
            case "disconnect" -> {
                if (s == null) { m.send(p, "not-connected"); break; }
                voice.disconnect(p.getUniqueId());
                m.send(p, "disconnected");
            }
            default -> m.send(p, "usage");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBS) {
                if (s.equals("reload") && !sender.hasPermission("voicebridge.admin")) continue;
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        }
        return out;
    }
}
