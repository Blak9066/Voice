package me.voicebridge;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * /vc menu.
 *  - Bedrock players (Floodgate) get a native form with toggles + dropdowns.
 *  - Java players get a small chest GUI.
 */
public final class MenuService implements Listener {
    private static final int SLOT_MIC = 10, SLOT_HEAR = 11, SLOT_NOISE = 12, SLOT_IN = 14, SLOT_OUT = 15;

    private static final class Holder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final VoiceBridgePlugin plugin;
    private final boolean floodgate;

    public MenuService(VoiceBridgePlugin plugin) {
        this.plugin = plugin;
        this.floodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
    }

    public void open(Player p) {
        VoiceSession s = plugin.voice().session(p.getUniqueId());
        if (s == null) {
            plugin.messages().send(p, "not-connected");
            return;
        }
        if (floodgate && FloodgateHook.isBedrock(p.getUniqueId())) {
            FloodgateHook.open(plugin, p, s);
            return;
        }
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, 27, plugin.messages().component("&9" + plugin.messages().raw("menu-title")));
        holder.inventory = inv;
        render(inv, s);
        p.openInventory(inv);
    }

    // ───────────── Java chest GUI ─────────────

    private void render(Inventory inv, VoiceSession s) {
        Messages m = plugin.messages();
        ItemStack filler = item(Material.BLUE_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);

        inv.setItem(SLOT_MIC, toggle(Material.LIME_CONCRETE, Material.RED_CONCRETE, "menu-mic", !s.muted));
        inv.setItem(SLOT_HEAR, toggle(Material.NOTE_BLOCK, Material.BARRIER, "menu-hear", !s.deafened));
        inv.setItem(SLOT_NOISE, toggle(Material.REPEATER, Material.GRAY_CONCRETE, "menu-noise", s.noise));
        inv.setItem(SLOT_IN, device(Material.OBSERVER, "menu-mic-device", s.inputs, s.selectedInput));
        inv.setItem(SLOT_OUT, device(Material.JUKEBOX, "menu-speaker", s.outputs, s.selectedOutput));
    }

    private ItemStack toggle(Material on, Material off, String labelKey, boolean enabled) {
        Messages m = plugin.messages();
        return item(enabled ? on : off,
                "&f" + m.raw(labelKey) + " " + m.raw(enabled ? "state-on" : "state-off"),
                m.raw("menu-click-toggle"));
    }

    private ItemStack device(Material mat, String labelKey, List<VoiceSession.Device> list, String selected) {
        Messages m = plugin.messages();
        if (list.isEmpty()) return item(mat, "&f" + m.raw(labelKey), m.raw("menu-no-devices"));
        return item(mat, "&f" + m.raw(labelKey),
                m.raw("menu-current", "device", VoiceSession.nameOf(list, selected)),
                m.raw("menu-click-cycle"));
    }

    private ItemStack item(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(plugin.messages().component(name));
        List<net.kyori.adventure.text.Component> l = new ArrayList<>();
        for (String line : lore) l.add(plugin.messages().component(line));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;

        VoiceSession s = plugin.voice().session(p.getUniqueId());
        if (s == null) {
            p.closeInventory();
            return;
        }
        VoiceServer v = plugin.voice();
        switch (e.getSlot()) {
            case SLOT_MIC -> v.applyChanges(s, !s.muted, s.deafened, s.noise, null, null);
            case SLOT_HEAR -> v.applyChanges(s, s.muted, !s.deafened, s.noise, null, null);
            case SLOT_NOISE -> v.applyChanges(s, s.muted, s.deafened, !s.noise, null, null);
            case SLOT_IN -> v.applyChanges(s, s.muted, s.deafened, s.noise,
                    VoiceSession.nextDeviceId(s.inputs, s.selectedInput), null);
            case SLOT_OUT -> v.applyChanges(s, s.muted, s.deafened, s.noise,
                    null, VoiceSession.nextDeviceId(s.outputs, s.selectedOutput));
            default -> { return; }
        }
        render(e.getInventory(), s);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
