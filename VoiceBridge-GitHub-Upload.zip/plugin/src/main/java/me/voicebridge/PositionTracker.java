package me.voicebridge;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Copies player positions on the main thread every 2 ticks so the network threads
 * can read them without touching the Bukkit API.
 */
public final class PositionTracker {
    public record Pos(UUID world, double x, double y, double z, float yaw) {}

    private final Map<UUID, Pos> positions = new ConcurrentHashMap<>();

    public PositionTracker(VoiceBridgePlugin plugin) {
        Bukkit.getScheduler().runTaskTimer(plugin, this::refresh, 1L, 2L);
    }

    private void refresh() {
        Set<UUID> online = new HashSet<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Location l = p.getEyeLocation();
            positions.put(p.getUniqueId(),
                    new Pos(l.getWorld().getUID(), l.getX(), l.getY(), l.getZ(), l.getYaw()));
            online.add(p.getUniqueId());
        }
        positions.keySet().retainAll(online);
    }

    public Pos get(UUID id) {
        return positions.get(id);
    }

    public void remove(UUID id) {
        positions.remove(id);
    }
}
