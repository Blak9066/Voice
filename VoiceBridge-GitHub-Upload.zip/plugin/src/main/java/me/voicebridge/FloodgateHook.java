package me.voicebridge;

import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.List;
import java.util.UUID;

/** Only touched when the Floodgate plugin is installed. */
final class FloodgateHook {
    private FloodgateHook() {}

    static boolean isBedrock(UUID id) {
        try {
            return FloodgateApi.getInstance().isFloodgatePlayer(id);
        } catch (Throwable t) {
            return false;
        }
    }

    static void open(VoiceBridgePlugin plugin, Player p, VoiceSession s) {
        Messages m = plugin.messages();
        List<VoiceSession.Device> ins = s.inputs;
        List<VoiceSession.Device> outs = s.outputs;

        CustomForm.Builder form = CustomForm.builder()
                .title(m.plain("menu-title"))
                .toggle(m.plain("menu-mic"), !s.muted)
                .toggle(m.plain("menu-hear"), !s.deafened)
                .toggle(m.plain("menu-noise"), s.noise);

        if (!ins.isEmpty()) {
            form.dropdown(m.plain("menu-mic-device"), VoiceSession.indexOf(ins, s.selectedInput), names(ins));
        }
        if (!outs.isEmpty()) {
            form.dropdown(m.plain("menu-speaker"), VoiceSession.indexOf(outs, s.selectedOutput), names(outs));
        }

        form.validResultHandler(res -> {
            boolean mic = res.asToggle();
            boolean hear = res.asToggle();
            boolean noise = res.asToggle();
            String in = ins.isEmpty() ? null : ins.get(Math.min(res.asDropdown(), ins.size() - 1)).id();
            String out = outs.isEmpty() ? null : outs.get(Math.min(res.asDropdown(), outs.size() - 1)).id();
            plugin.voice().applyChanges(s, !mic, !hear, noise, in, out);
        });

        FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
    }

    private static String[] names(List<VoiceSession.Device> list) {
        return list.stream().map(VoiceSession.Device::name).toArray(String[]::new);
    }
}
