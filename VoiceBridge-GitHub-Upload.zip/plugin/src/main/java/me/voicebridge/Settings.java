package me.voicebridge;

import org.bukkit.configuration.file.FileConfiguration;

/** Immutable snapshot of config values (safe to read from network threads). */
public final class Settings {
    public final String bindHost, publicHost, keystore, keystorePassword, floodgatePrefix;
    public final int port, codeLength, codeExpireSeconds, maxFailedLogins, banSeconds, maxFrameBytes, maxFramesPerSecond;
    public final boolean tlsEnabled, stereoPan, joinHint, defaultNoise;
    public final double maxDistance, fullVolumeDistance, falloffExponent;

    public Settings(FileConfiguration c) {
        bindHost = c.getString("server.bind-host", "0.0.0.0");
        port = c.getInt("server.port", 25590);
        publicHost = c.getString("server.public-host", "your.server.ip");
        tlsEnabled = c.getBoolean("server.tls.enabled", false);
        keystore = c.getString("server.tls.keystore", "keystore.p12");
        keystorePassword = c.getString("server.tls.password", "");

        double max = Math.max(1.0, c.getDouble("voice.max-distance", 30.0));
        double full = Math.max(0.0, c.getDouble("voice.full-volume-distance", 2.0));
        maxDistance = max;
        fullVolumeDistance = Math.min(full, max - 0.5);
        falloffExponent = Math.max(0.1, c.getDouble("voice.falloff-exponent", 1.5));
        stereoPan = c.getBoolean("voice.stereo-pan", true);
        defaultNoise = c.getBoolean("voice.default-noise-suppression", true);

        codeLength = Math.min(10, Math.max(4, c.getInt("code.length", 6)));
        codeExpireSeconds = Math.max(30, c.getInt("code.expire-seconds", 300));

        maxFailedLogins = Math.max(1, c.getInt("security.max-failed-logins", 5));
        banSeconds = Math.max(5, c.getInt("security.ban-seconds", 120));
        maxFrameBytes = Math.max(256, c.getInt("security.max-frame-bytes", 4096));
        maxFramesPerSecond = Math.max(10, c.getInt("security.max-frames-per-second", 80));

        floodgatePrefix = c.getString("floodgate-prefix", ".");
        joinHint = c.getBoolean("join-hint", true);
    }

    /** 0.0 (silent) .. 1.0 (full) depending on distance in blocks. */
    public double gainFor(double distance) {
        if (distance >= maxDistance) return 0.0;
        if (distance <= fullVolumeDistance) return 1.0;
        double t = (distance - fullVolumeDistance) / (maxDistance - fullVolumeDistance);
        return Math.pow(1.0 - t, falloffExponent);
    }
}
