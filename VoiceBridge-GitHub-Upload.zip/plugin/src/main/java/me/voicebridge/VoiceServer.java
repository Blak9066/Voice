package me.voicebridge;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import me.voicebridge.CodeManager.PendingCode;
import me.voicebridge.PositionTracker.Pos;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.java_websocket.WebSocket;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.extensions.IExtension;
import org.java_websocket.framing.CloseFrame;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.protocols.IProtocol;
import org.java_websocket.server.DefaultSSLWebSocketServerFactory;
import org.java_websocket.server.WebSocketServer;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * WebSocket hub between the phone apps and the game.
 *
 * Binary protocol
 *   client -> server : [0x01][seq u16 BE][opus payload...]
 *   server -> client : [0x02][srcId i32 BE][gain u8 0..255][pan i8 -100..100][seq u16 BE][opus payload...]
 *
 * Text protocol: JSON, see README.md
 */
public final class VoiceServer extends WebSocketServer {
    private static final Gson GSON = new Gson();
    private static final byte T_CLIENT_FRAME = 0x01;
    private static final byte T_SERVER_FRAME = 0x02;
    private static final long FAIL_WINDOW_MS = 10 * 60_000L;

    private final VoiceBridgePlugin plugin;
    private final Map<WebSocket, VoiceSession> byConn = new ConcurrentHashMap<>();
    private final Map<UUID, VoiceSession> byPlayer = new ConcurrentHashMap<>();
    /** ip -> [failCount, blockedUntil, firstFailAt] */
    private final Map<String, long[]> failures = new ConcurrentHashMap<>();
    private final AtomicInteger ids = new AtomicInteger(1);
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "VoiceBridge-Scheduler");
        t.setDaemon(true);
        return t;
    });

    public VoiceServer(VoiceBridgePlugin plugin) throws Exception {
        super(new InetSocketAddress(plugin.settings().bindHost, plugin.settings().port),
                List.<Draft>of(new Draft_6455(Collections.<IExtension>emptyList(),
                        Collections.<IProtocol>emptyList(), 16 * 1024)));
        this.plugin = plugin;
        setReuseAddr(true);
        setTcpNoDelay(true);
        setConnectionLostTimeout(30);
        if (plugin.settings().tlsEnabled) setupTls(plugin.settings());
    }

    private void setupTls(Settings cfg) throws Exception {
        char[] pw = cfg.keystorePassword.toCharArray();
        KeyStore ks = KeyStore.getInstance("PKCS12");
        try (InputStream in = new FileInputStream(new File(plugin.getDataFolder(), cfg.keystore))) {
            ks.load(in, pw);
        }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, pw);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), null, null);
        setWebSocketFactory(new DefaultSSLWebSocketServerFactory(ctx));
    }

    public void launch() {
        start();
        scheduler.scheduleAtFixedRate(this::tick, 500, 500, TimeUnit.MILLISECONDS);
    }

    public void shutdown() {
        scheduler.shutdownNow();
        try {
            stop(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ───────────────────────── lifecycle ─────────────────────────

    @Override
    public void onStart() {
        plugin.getLogger().info("Voice server listening on " + plugin.settings().bindHost + ":" + plugin.settings().port
                + (plugin.settings().tlsEnabled ? " (TLS)" : ""));
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        // must log in within 10 s
        scheduler.schedule(() -> {
            if (conn.isOpen() && !byConn.containsKey(conn)) conn.close(CloseFrame.POLICY_VALIDATION, "login timeout");
        }, 10, TimeUnit.SECONDS);
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        VoiceSession s = byConn.remove(conn);
        if (s != null) {
            byPlayer.remove(s.playerId, s);
            notifyPlayer(s.playerId, "voice-disconnected");
        }
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        if (conn == null) {
            plugin.getLogger().severe("Voice server error: " + ex.getMessage()
                    + " (is the port already in use / not allocated by your host?)");
        }
    }

    // ───────────────────────── text messages ─────────────────────────

    @Override
    public void onMessage(WebSocket conn, String message) {
        JsonObject o;
        try {
            o = JsonParser.parseString(message).getAsJsonObject();
        } catch (Exception e) {
            return;
        }
        String type = str(o, "type");
        if (type.equals("login")) {
            handleLogin(conn, o);
            return;
        }
        VoiceSession s = byConn.get(conn);
        if (s == null) {
            conn.close(CloseFrame.POLICY_VALIDATION, "not logged in");
            return;
        }
        try {
            switch (type) {
                case "state" -> handleState(s, o);
                case "devices" -> handleDevices(s, o);
                default -> { /* ignore unknown */ }
            }
        } catch (Exception ignored) {
            // malformed payload – ignore
        }
    }

    private void handleLogin(WebSocket conn, JsonObject o) {
        Settings cfg = plugin.settings();
        String ip = ip(conn);
        if (isBlocked(ip)) {
            sendError(conn, "rate_limited", "Too many attempts, try again later.");
            conn.close(CloseFrame.POLICY_VALIDATION, "rate limited");
            return;
        }
        if (byConn.containsKey(conn)) return;

        String name = str(o, "name");
        String code = str(o, "code");
        PendingCode pc = plugin.codes().find(code);
        if (pc == null || !normalize(pc.playerName(), cfg.floodgatePrefix).equals(normalize(name, cfg.floodgatePrefix))) {
            registerFailure(ip, cfg);
            sendError(conn, "invalid_login", "Invalid name or code.");
            conn.close(CloseFrame.POLICY_VALIDATION, "invalid login");
            return;
        }
        if (plugin.positions().get(pc.playerId()) == null) {
            sendError(conn, "player_offline", "You are not online on the server.");
            conn.close(CloseFrame.POLICY_VALIDATION, "offline");
            return;
        }
        plugin.codes().consume(code, pc);
        failures.remove(ip);

        VoiceSession s = new VoiceSession(conn, pc.playerId(), pc.playerName(), ids.getAndIncrement(), cfg.defaultNoise);
        VoiceSession prev = byPlayer.put(pc.playerId(), s);
        byConn.put(conn, s);
        if (prev != null) {
            byConn.remove(prev.conn);
            if (prev.conn.isOpen()) prev.conn.close(CloseFrame.NORMAL, "replaced by a new connection");
        }

        JsonObject welcome = new JsonObject();
        welcome.addProperty("type", "welcome");
        welcome.addProperty("id", s.id);
        welcome.addProperty("name", stripPrefix(pc.playerName(), cfg.floodgatePrefix));
        welcome.addProperty("maxDistance", cfg.maxDistance);
        JsonObject audio = new JsonObject();
        audio.addProperty("codec", "opus");
        audio.addProperty("sampleRate", 48000);
        audio.addProperty("frameMs", 20);
        audio.addProperty("channels", 1);
        welcome.add("audio", audio);
        welcome.add("state", stateJson(s));
        send(conn, welcome);
        notifyPlayer(pc.playerId(), "voice-connected");
    }

    private void handleState(VoiceSession s, JsonObject o) {
        if (o.has("muted")) s.muted = o.get("muted").getAsBoolean();
        if (o.has("deafened")) s.deafened = o.get("deafened").getAsBoolean();
        if (o.has("noise")) s.noise = o.get("noise").getAsBoolean();
    }

    private void handleDevices(VoiceSession s, JsonObject o) {
        s.inputs = parseDevices(o.getAsJsonArray("inputs"));
        s.outputs = parseDevices(o.getAsJsonArray("outputs"));
        if (o.has("selectedInput")) s.selectedInput = o.get("selectedInput").getAsString();
        if (o.has("selectedOutput")) s.selectedOutput = o.get("selectedOutput").getAsString();
    }

    private List<VoiceSession.Device> parseDevices(JsonArray arr) {
        List<VoiceSession.Device> list = new ArrayList<>();
        if (arr == null) return list;
        for (JsonElement e : arr) {
            if (list.size() >= 16) break;
            JsonObject d = e.getAsJsonObject();
            String name = str(d, "name");
            if (name.length() > 40) name = name.substring(0, 40);
            list.add(new VoiceSession.Device(str(d, "id"), name));
        }
        return list;
    }

    // ───────────────────────── audio ─────────────────────────

    @Override
    public void onMessage(WebSocket conn, ByteBuffer buf) {
        VoiceSession s = byConn.get(conn);
        if (s == null) return;
        Settings cfg = plugin.settings();

        int len = buf.remaining();
        if (len < 4 || len > cfg.maxFrameBytes) return;
        ByteBuffer in = buf.duplicate();
        if (in.get() != T_CLIENT_FRAME) return;
        if (s.muted || !s.allowFrame(cfg.maxFramesPerSecond)) return;

        Pos src = plugin.positions().get(s.playerId);
        if (src == null) return;

        byte[] payload = new byte[in.remaining()]; // seq + opus
        in.get(payload);

        for (VoiceSession t : byPlayer.values()) {
            if (t == s || t.deafened) continue;
            Pos dst = plugin.positions().get(t.playerId);
            if (dst == null || !dst.world().equals(src.world())) continue;

            double dist = distance(src, dst);
            if (dist >= cfg.maxDistance) continue; // too far: nothing is sent at all
            double gain = cfg.gainFor(dist);
            if (gain < 0.004) continue;
            if (!t.conn.isOpen() || t.conn.hasBufferedData()) continue; // slow client: drop frame

            ByteBuffer out = ByteBuffer.allocate(7 + payload.length);
            out.put(T_SERVER_FRAME);
            out.putInt(s.id);
            out.put((byte) Math.round(gain * 255));
            out.put((byte) pan(dst, src, cfg.stereoPan));
            out.put(payload);
            out.flip();
            try {
                t.conn.send(out);
            } catch (Exception ignored) {
                // connection closing
            }
        }
    }

    private static double distance(Pos a, Pos b) {
        double dx = a.x() - b.x(), dy = a.y() - b.y(), dz = a.z() - b.z();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** -100 = fully left ear, +100 = fully right ear, relative to where the listener looks. */
    private static int pan(Pos listener, Pos speaker, boolean enabled) {
        if (!enabled) return 0;
        double dx = speaker.x() - listener.x(), dz = speaker.z() - listener.z();
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz < 0.01) return 0;
        double yaw = Math.toRadians(listener.yaw());
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw); // listener's right-hand vector (Minecraft yaw)
        double p = (dx * rx + dz * rz) / horiz;
        p *= Math.min(1.0, horiz / 2.0); // don't swing wildly when someone is right next to you
        return (int) Math.round(Math.max(-1.0, Math.min(1.0, p)) * 100);
    }

    // ───────────────────────── periodic: nearby list ─────────────────────────

    private void tick() {
        try {
            Settings cfg = plugin.settings();
            for (VoiceSession s : byPlayer.values()) {
                Pos me = plugin.positions().get(s.playerId);
                if (me == null) continue;
                JsonArray arr = new JsonArray();
                for (VoiceSession t : byPlayer.values()) {
                    if (t == s) continue;
                    Pos o = plugin.positions().get(t.playerId);
                    if (o == null || !o.world().equals(me.world())) continue;
                    double d = distance(me, o);
                    if (d >= cfg.maxDistance) continue;
                    JsonObject e = new JsonObject();
                    e.addProperty("id", t.id);
                    e.addProperty("name", stripPrefix(t.playerName, cfg.floodgatePrefix));
                    e.addProperty("dist", Math.round(d * 10) / 10.0);
                    e.addProperty("muted", t.muted);
                    arr.add(e);
                }
                JsonObject msg = new JsonObject();
                msg.addProperty("type", "nearby");
                msg.add("players", arr);
                send(s.conn, msg);
            }
            long now = System.currentTimeMillis();
            failures.entrySet().removeIf(e -> e.getValue()[1] < now && e.getValue()[2] + FAIL_WINDOW_MS < now);
        } catch (Exception ex) {
            plugin.getLogger().warning("Voice tick failed: " + ex.getMessage());
        }
    }

    // ───────────────────────── API used by commands / menus ─────────────────────────

    public VoiceSession session(UUID playerId) {
        return byPlayer.get(playerId);
    }

    public void applyChanges(VoiceSession s, boolean muted, boolean deafened, boolean noise,
                             String inputId, String outputId) {
        boolean changed = s.muted != muted || s.deafened != deafened || s.noise != noise;
        s.muted = muted;
        s.deafened = deafened;
        s.noise = noise;
        if (changed) send(s.conn, stateJsonMessage(s));
        if (inputId != null && !inputId.equals(s.selectedInput)) {
            s.selectedInput = inputId;
            sendSetDevice(s, "input", inputId);
        }
        if (outputId != null && !outputId.equals(s.selectedOutput)) {
            s.selectedOutput = outputId;
            sendSetDevice(s, "output", outputId);
        }
    }

    public void disconnect(UUID playerId) {
        VoiceSession s = byPlayer.remove(playerId);
        if (s == null) return;
        byConn.remove(s.conn);
        if (s.conn.isOpen()) s.conn.close(CloseFrame.NORMAL, "disconnected");
    }

    // ───────────────────────── helpers ─────────────────────────

    private JsonObject stateJson(VoiceSession s) {
        JsonObject st = new JsonObject();
        st.addProperty("muted", s.muted);
        st.addProperty("deafened", s.deafened);
        st.addProperty("noise", s.noise);
        return st;
    }

    private JsonObject stateJsonMessage(VoiceSession s) {
        JsonObject m = stateJson(s);
        m.addProperty("type", "state");
        return m;
    }

    private void sendSetDevice(VoiceSession s, String kind, String id) {
        JsonObject m = new JsonObject();
        m.addProperty("type", "setDevice");
        m.addProperty("kind", kind);
        m.addProperty("id", id);
        send(s.conn, m);
    }

    private void sendError(WebSocket conn, String code, String message) {
        JsonObject m = new JsonObject();
        m.addProperty("type", "error");
        m.addProperty("code", code);
        m.addProperty("message", message);
        send(conn, m);
    }

    private void send(WebSocket conn, JsonObject obj) {
        if (conn == null || !conn.isOpen()) return;
        try {
            conn.send(GSON.toJson(obj));
        } catch (Exception ignored) {
            // connection closing
        }
    }

    private void notifyPlayer(UUID id, String key) {
        if (!plugin.isEnabled()) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player p = Bukkit.getPlayer(id);
            if (p != null) plugin.messages().send(p, key);
        });
    }

    private static String str(JsonObject o, String key) {
        try {
            return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
        } catch (Exception e) {
            return "";
        }
    }

    private static String ip(WebSocket conn) {
        try {
            return conn.getRemoteSocketAddress().getAddress().getHostAddress();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private boolean isBlocked(String ip) {
        long[] f = failures.get(ip);
        return f != null && f[1] > System.currentTimeMillis();
    }

    private void registerFailure(String ip, Settings cfg) {
        long now = System.currentTimeMillis();
        failures.compute(ip, (k, f) -> {
            if (f == null || f[2] + FAIL_WINDOW_MS < now) f = new long[]{0, 0, now};
            f[0]++;
            if (f[0] >= cfg.maxFailedLogins) {
                f[1] = now + cfg.banSeconds * 1000L;
                f[0] = 0;
            }
            return f;
        });
    }

    /** Removes Floodgate's prefix (e.g. ".Steve" -> "Steve"). */
    public static String stripPrefix(String name, String prefix) {
        String n = name == null ? "" : name.trim();
        if (prefix != null && !prefix.isEmpty() && n.startsWith(prefix)) n = n.substring(prefix.length());
        return n;
    }

    private static String normalize(String name, String prefix) {
        return stripPrefix(name, prefix).replace(' ', '_').toLowerCase(Locale.ROOT);
    }
}
