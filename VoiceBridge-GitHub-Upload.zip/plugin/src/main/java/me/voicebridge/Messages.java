package me.voicebridge;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;

public final class Messages {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final VoiceBridgePlugin plugin;

    public Messages(VoiceBridgePlugin plugin) {
        this.plugin = plugin;
    }

    /** Raw string from config with {placeholders} replaced, '&' codes untouched. */
    public String raw(String key, String... kv) {
        String s = plugin.getConfig().getString("messages." + key, "&c[missing: " + key + "]");
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        return s;
    }

    /** Same as raw() but with '§' colour codes (for Bedrock forms). */
    public String plain(String key, String... kv) {
        return raw(key, kv).replace('&', '§');
    }

    public Component component(String legacyText) {
        return LEGACY.deserialize(legacyText).decoration(TextDecoration.ITALIC, false);
    }

    public Component get(String key, String... kv) {
        return component(plugin.getConfig().getString("messages.prefix", "") + raw(key, kv));
    }

    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(get(key, kv));
    }
}
