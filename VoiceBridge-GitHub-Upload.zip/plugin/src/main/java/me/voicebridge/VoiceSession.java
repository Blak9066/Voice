package me.voicebridge;

import org.java_websocket.WebSocket;

import java.util.List;
import java.util.UUID;

/** One connected phone app. */
public final class VoiceSession {
    public record Device(String id, String name) {}

    public final WebSocket conn;
    public final UUID playerId;
    public final String playerName;
    public final int id;

    public volatile boolean muted;
    public volatile boolean deafened;
    public volatile boolean noise;

    public volatile List<Device> inputs = List.of();
    public volatile List<Device> outputs = List.of();
    public volatile String selectedInput;
    public volatile String selectedOutput;

    private long windowStart;
    private int windowCount;

    public VoiceSession(WebSocket conn, UUID playerId, String playerName, int id, boolean noise) {
        this.conn = conn;
        this.playerId = playerId;
        this.playerName = playerName;
        this.id = id;
        this.noise = noise;
    }

    /** Simple per-second frame limiter so a broken/malicious client can't flood the server. */
    public synchronized boolean allowFrame(int maxPerSecond) {
        long now = System.currentTimeMillis();
        if (now - windowStart >= 1000) {
            windowStart = now;
            windowCount = 0;
        }
        return ++windowCount <= maxPerSecond;
    }

    public static String nextDeviceId(List<Device> list, String current) {
        if (list.isEmpty()) return null;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id().equals(current)) return list.get((i + 1) % list.size()).id();
        }
        return list.get(0).id();
    }

    public static int indexOf(List<Device> list, String id) {
        for (int i = 0; i < list.size(); i++) if (list.get(i).id().equals(id)) return i;
        return 0;
    }

    public static String nameOf(List<Device> list, String id) {
        for (Device d : list) if (d.id().equals(id)) return d.name();
        return list.isEmpty() ? "-" : list.get(0).name();
    }
}
