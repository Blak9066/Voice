# VoiceBridge app – setup

1. Install Flutter, then create a fresh project and drop these files in:
       flutter create --org me.voicebridge --project-name voicebridge_app voicebridge_app
       (copy this folder's  lib/  and  pubspec.yaml  over the new project's)
       cd voicebridge_app && flutter pub get

2. ANDROID – android/app/src/main/AndroidManifest.xml
   Inside <manifest> (above <application>):
       <uses-permission android:name="android.permission.INTERNET"/>
       <uses-permission android:name="android.permission.RECORD_AUDIO"/>
       <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
       <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
       <uses-permission android:name="android.permission.WAKE_LOCK"/>
       <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE"/>
   On the <application ...> tag add:   android:usesCleartextTraffic="true"
   Inside <application> add:
       <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
                android:foregroundServiceType="microphone" android:exported="false"/>
   In android/app/build.gradle(.kts): set  minSdk = 24

3. iOS – ios/Runner/Info.plist (inside the main <dict>):
       <key>NSMicrophoneUsageDescription</key><string>Voice chat needs the microphone.</string>
       <key>UIBackgroundModes</key><array><string>audio</string></array>
       <key>NSAppTransportSecurity</key><dict><key>NSAllowsArbitraryLoads</key><true/></dict>
   ios/Podfile: platform :ios, '13.0'

4. Run / build:
       flutter run
       flutter build apk --release      # -> build/app/outputs/flutter-apk/app-release.apk
